import { createApp } from 'vue'
import App from './popup.vue'

createApp(App).mount('#app')
